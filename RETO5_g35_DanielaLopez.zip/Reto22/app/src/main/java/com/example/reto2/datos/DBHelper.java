package com.example.reto2.datos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private SQLiteDatabase sqLiteDatabase;

    public DBHelper(Context context) {
        super(context, "Reto6.db", null, 1);
        sqLiteDatabase = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE SUCURSALES(" +
                "id STRING PRIMARY KEY AUTOINCREMENT," +
                "name VARCHAR," +
                "description VARCHAR," +
                "price VARCHAR," +
                "favorite VARCHAR," +
                "image BLOB)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS PRODUCTOS");
    }

    public void insertProducto(String name, String description,String precio, String favorite, byte[] image){
        String sql = "INSERT INTO SUCURSALES VALUES(null, ?, ?, ?, ?, ?)";
        SQLiteStatement statement = sqLiteDatabase.compileStatement(sql);
        statement.clearBindings();

        statement.bindString(1, name);
        statement.bindString(2, description);
        statement.bindString(3, precio);
        statement.bindString(4, favorite);
        statement.bindBlob(5, image);

        statement.executeInsert();
    }

    public Cursor getProductos(String TABLE_NAME){
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM SUCURSALES",null);
        return cursor;
    }

}