package com.example.reto2.datos;

import android.content.Context;
import android.database.sqlite.SQLiteStatement;
import android.os.Build;
import android.os.Handler;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.annotation.RequiresApi;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.reto2.adaptadores.ProductoAdapter;
import com.example.reto2.casos_uso.CasoUsoProducto;
import com.example.reto2.modelos.Producto;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ApiOracle {
    private RequestQueue queue;
    private CasoUsoProducto casoUsoProducto;
    private String url ="https://g490330b8645dc0-proyectociclo4.adb.sa-saopaulo-1.oraclecloudapps.com/ords/admin/proyectopure/productos";
    private Context context;

    public ApiOracle(Context context) {
        this.context = context;
        queue = Volley.newRequestQueue(context);
        casoUsoProducto = new CasoUsoProducto();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void insertProducto(String name, String description,String price, ImageView imageView) {
        String image = casoUsoProducto.imageViewToString(imageView);

        JSONObject json = new JSONObject();
        try {
            json.put("name", name);
            json.put("description", description);
            json.put("price", price);
            json.put("image", image);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // PETICION(POST,DELETE,PUT,GET), URL, JSON, RESPONSE.LISTENER, ERROR.LISTENER
        JsonObjectRequest postSucursal = new JsonObjectRequest(Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(postSucursal);
    }
    // PETICION(POST,DELETE,PUT,GET), URL, JSON, RESPONSE.LISTENER, ERROR.LISTENER
    public void getProductoById(String id, EditText name, EditText description, EditText price, ImageView imageView){
        JsonObjectRequest getProductoById = new JsonObjectRequest(Request.Method.GET, url+"/"+id, null, new Response.Listener<JSONObject>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("items");
                    for(int i=0; i<jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        name.setText(jsonObject.getString("name"));
                        description.setText(jsonObject.getString("description"));
                        price.setText(jsonObject.getString("price"));
                        byte[] img = casoUsoProducto.stringToByte(jsonObject.getString("image"));
                        imageView.setImageBitmap(casoUsoProducto.byteToBitmap(img));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(getProductoById);
    }

    public void getProdcuto(EditText name, EditText description, EditText price, ImageView imageView){
        // PETICION(POST,DELETE,PUT,GET), URL, JSON, RESPONSE.LISTENER, ERROR.LISTENER
        JsonObjectRequest getAllProducto = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("items");
                    for(int i=0; i<jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        new Handler().postDelayed(new Runnable() {
                            @RequiresApi(api = Build.VERSION_CODES.O)
                            @Override
                            public void run() {
                                try {
                                    name.setText(jsonObject.getString("name"));
                                    description.setText(jsonObject.getString("description"));
                                    price.setText(jsonObject.getString("price"));
                                    byte[] img = casoUsoProducto.stringToByte(jsonObject.getString("image"));
                                    imageView.setImageBitmap(casoUsoProducto.byteToBitmap(img));
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, (i+2)*1000);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(getAllProducto);
    }

    public void deleteProducto (String id){
        JsonObjectRequest deleteProducto = new JsonObjectRequest(Request.Method.DELETE, url + "/" + id, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(deleteProducto);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void updateProducto (String id, String name, String description, String price, ImageView imageView) {
        String image = casoUsoProducto.imageViewToString(imageView);

        JSONObject json = new JSONObject();
        try {
            json.put("id", id);
            json.put("name", name);
            json.put("description", description);
            json.put("price", price);
            json.put("image", image);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // PETICION(POST,DELETE,PUT,GET), URL, JSON, RESPONSE.LISTENER, ERROR.LISTENER
        JsonObjectRequest putProducto = new JsonObjectRequest(Request.Method.PUT, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue.add(putProducto);
    }

    public void getAllProductosFragment(GridView gridView, ProgressBar progressBar){
        // PETICION(POST,DELETE,PUT,GET), URL, JSON, RESPONSE.LISTENER, ERROR.LISTENER
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onResponse(JSONObject response) {
                ArrayList<Producto> lista = new ArrayList<>();
                try {
                    JSONArray jsonArray = response.getJSONArray("items");
                    for(int i=0;i<jsonArray.length();i++){
                     JSONObject jsonObject = jsonArray.getJSONObject(i);
                        Producto producto = new Producto(
                                jsonObject.getString("id"),
                                jsonObject.getString("name"),
                                jsonObject.getString("desccription"),
                                jsonObject.getString("price"),
                                jsonObject.getString("is_favorite"),
                                casoUsoProducto.stringToByte(jsonObject.getString("image"))

                        );
                        lista.add(producto);
                    }
                    ProductoAdapter productoAdapter = new ProductoAdapter(context, lista);
                    progressBar.setVisibility(ProgressBar.INVISIBLE);

                    gridView.setAdapter(productoAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue.add(jsonObjectRequest);
    }

    /*public void getAllMaps(GoogleMap googleMap){
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("items");
                    for (int i=0; i<jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        Producto producto = new Producto(
                                jsonObject.getString("id"),
                                jsonObject.getString("name"),
                                jsonObject.getString("location"),
                                jsonObject.getString("price"),
                                jsonObject.getString("is_favorite"),
                                casoUsoProducto.stringToByte(jsonObject.getString("image"))
                        );

                        MarkerOptions markerOptions = new MarkerOptions();
                        markerOptions.title(producto.getName());
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue.add(jsonObjectRequest);
    }*/

    public void updateFavorite(String id, Boolean favorite){
        JSONObject json = new JSONObject();
        int send = 0;
        if(favorite){
            send = 1;
        }
        try {
            json.put("is_favorite", send);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.PUT, url+"/"+id, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue.add(jsonObjectRequest);
    }

}
