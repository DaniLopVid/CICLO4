package com.example.reto2.ui.productos;

import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.reto2.FormActivity;
import com.example.reto2.R;
import com.example.reto2.adaptadores.ProductoAdapter;
import com.example.reto2.adaptadores.SucursalAdapter;
import com.example.reto2.casos_uso.CasoUsoProducto;
import com.example.reto2.databinding.FragmentProductosBinding;
import com.example.reto2.datos.ApiOracle;
import com.example.reto2.datos.DBHelper;
import com.example.reto2.modelos.Producto;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ProductosFragment extends Fragment {

    public class HomeFragment extends Fragment {
        private TextView text_home;
        private final int REQUEST_CODE_GALLERY = 999;
}
    private final int REQUEST_CODE_GALLERY = 999;
    private String TABLE_NAME = "PRODUCTOS";
    private CasoUsoProducto casoUsoProducto;
    private GridView gridView;
    private DBHelper dbHelper;
    private ArrayList<Producto> productos;

    private Button btnConsultar, btnEliminar, btnActualizar;
    private EditText name, description, price, id;
    private ImageView imgSelectedOracle;

    private FragmentProductosBinding binding;
    private String url="";

    private ApiOracle api;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentProductosBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        api = new ApiOracle(getContext());

        text_producto = (TextView) root.findViewById(R.id.text_producto);

        btnEliminar = (Button) root.findViewById(R.id.btnEliminar);
        btnConsultar = (Button) root.findViewById(R.id.btnConsultar);
        btnActualizar = (Button) root.findViewById(R.id.btnActualizar);

        id = (EditText) root.findViewById(R.id.editIdItem);
        name = (EditText) root.findViewById(R.id.editCampo1);
        description = (EditText) root.findViewById(R.id.editCampo2);
        price = (EditText) root.findViewById(R.id.editCampo3);

        imgSelectedOracle = (ImageView) root.findViewById(R.id.imgSelected);



        RequestQueue queue = Volley.newRequestQueue(getContext());
        url ="https://g490330b8645dc0-proyectociclo4.adb.sa-saopaulo-1.oraclecloudapps.com/ords/admin/proyectopure/productos";

        btnConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idTest = id.getText().toString().trim();
                if(idTest.equals("")){
                    api.getProdcuto(name, description, price, imgSelectedOracle);
                }else {
                    api.getProductoById(idTest, name, description, price, imgSelectedOracle);
                }
            }
        });

        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idTest = id.getText().toString().trim();
                api.deleteProducto(idTest);
            }
        });

        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                String idUpdate = id.getText().toString();
                String nameUpdate = name.getText().toString();
                String locationUpdate = Producto.getText().toString();
                api.updateProducto(idUpdate, nameUpdate, descripitonUpdate, priceUpdate, imgSelectedOracle);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        RequestQueue queue = Volley.newRequestQueue(getContext());
        url ="https://g490330b8645dc0-proyectociclo4.adb.sa-saopaulo-1.oraclecloudapps.com/ords/admin/proyectopure/productos";



        switch (item.getItemId()){
            case R.id.action_add:
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                        (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    text_producto.setText(response.getString("items"));
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                text_producto.setText("Response: " + error.toString());
                            }
                        });
                queue.add(jsonObjectRequest);
                return true;

            case R.id.action_show:

                JSONObject json = new JSONObject();




                try {
                    json.put("name","pepe4");
                    json.put("price", "pepePrice4");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Toast.makeText(getContext(), response.toString(), Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Toast.makeText(getContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                });

                Volley.newRequestQueue(getContext()).add(jsonRequest);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }